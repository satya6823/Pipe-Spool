import React, { useCallback, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getAllEntity, selectEntity, setEntity } from "../redux/slice/entitySlice";
import Logout from "./Logout";
import { notifications } from "../assets/data.json";
import { Link, useLocation } from "react-router-dom";


const imagebaseUrl = import.meta.env.VITE_IMAGE_URL;

const Header = () => {
  const dispatch = useDispatch();
  const location=useLocation();
  const hideHeader = ["/spool", "/drawing-spool"].includes(location.pathname);
  const user = JSON.parse(localStorage.getItem('user'))

  const userData = useSelector((state) => state.authuser)
  const background = useSelector((state) => state.entity.primaryColor);
  const selected=useSelector(state=>state.entity.selected)
  console.log(selected)
  
  const Logo = useSelector((state) => state.entity.selectedLogo);
  const allEntity = useSelector((state) => state.entity.list);

  const [showLogout, setShowLogoutModal] = useState(false);
  // const [selectedEntity, setSelectedEntity] = useState("");
  const [notification] = useState(notifications || []);

//  const handleSelectEntity =(entity) => {
//   if (!entity) return;

//   //  dispatch(setEntity(entity));
//   //  dispatch(selectEntity({ entity_id: entity.id }));
//    if (!selected || selected.id !== entity.id) {
//     dispatch(setEntity(entity));
//     dispatch(selectEntity({ entity_id: entity.id }));
//   }
// }


// const handleSelectEntity = useCallback((entity) => {
//   if (!entity) return;

//   if (!selected || selected.id !== entity.id) {
//     dispatch(setEntity(entity));
//     dispatch(selectEntity({ entity_id: entity.id }));
//     localStorage.setItem("selectedEntity", JSON.stringify(entity)); // persist
//   }
// }, [dispatch, selected]);

// const handleSelectEntity = useCallback(
//   (entity) => {
//     if (!entity) return;

//     if (!selected || selected.id !== entity.id) {
//       dispatch(setEntity(entity));

//       dispatch(selectEntity({ entity_id: entity.id }));
//       localStorage.setItem("selectedEntity", JSON.stringify(entity));
//     }
//   },
//   [dispatch, selected]

useEffect(() => {
  if (selected?.id) {
    dispatch(selectEntity({ entity_id: selected.id }));
  }
}, [selected?.id, dispatch]);

const handleSelectEntity = useCallback(
  (entity) => {
    if (!entity) return;

    if (!selected || selected.id !== entity.id) {
      dispatch(setEntity(entity));
      localStorage.setItem("selectedEntity", JSON.stringify(entity));
    }
  },
  [dispatch, selected]
);
// );



// useEffect(() => {
//   if (allEntity?.length > 0 && !selected) {
//     handleSelectEntity(allEntity[0]); // calls API once
//   }
// }, [allEntity, selected, handleSelectEntity]);

  useEffect(() => {
    dispatch(getAllEntity());
  }, [hideHeader, dispatch]);


// useEffect(() => {
//   if (!allEntity || allEntity.length === 0) return;

//   const savedEntity = JSON.parse(localStorage.getItem("selectedEntity"));

//   let entityToSelect;

//   if (savedEntity) {
//     entityToSelect = allEntity.find(e => e.id === savedEntity.id) || allEntity[0];
//   } else {
//     entityToSelect = allEntity[0];
//   }

//   handleSelectEntity(entityToSelect);
// }, [allEntity, handleSelectEntity]);

const savedEntity = JSON.parse(localStorage.getItem("selectedEntity"));

// Once allEntity is loaded
useEffect(() => {
  if (!allEntity || allEntity.length === 0) return;

  let entityToSelect;

  if (selected) {
    // already selected, do nothing
    return;
  } else if (savedEntity) {
    entityToSelect = allEntity.find(e => e.id === savedEntity.id) || allEntity[0];
  } else {
    entityToSelect = allEntity[0];
  }

  dispatch(setEntity(entityToSelect));
  dispatch(selectEntity({ entity_id: entityToSelect.id }));
}, [allEntity, selected, dispatch]);


useEffect(() => {
  const savedEntity = JSON.parse(localStorage.getItem("selectedEntity"));
  console.log(savedEntity)
  if (savedEntity) {
    dispatch(setEntity(savedEntity));
  }
}, [dispatch]);


  return (
    <>
      {/* Header does NOT control whole page background */}
      <header>
        <div className="container">
          <div className="row">
            <div className="col-lg-6 col-md-3">
              <div className="header-in">
                {/* <div className="logo">
                  <img src="/images/projects/logo-w.svg" alt="" />
                </div> */}
                 <Link to="/dashboard">
              <img src="/images/projects/logo-w.svg" alt="Logo" />
               </Link>
                <div className="logo-data">
                  <img src="/images/projects/rpr-spool-tracker.svg" alt="" />
                  <p>
                    Logged in as <span>{user?.name}</span>
                  </p>
                </div>
              </div>
            </div>

            <div className="col-lg-6 col-md-9">
              <div className="header-right">
                {/* ENTITY SWITCHER */}
               {!hideHeader && (<div className="entity-swtich entity-dropdown">
                  <button
                    className="dropdown-toggle"
                    type="button"
                    data-bs-toggle="dropdown"
                  >
                    <div className="entity-logo">
                      <img 
                       src={Logo ? `${imagebaseUrl+Logo}` : "/images/projects/entity-logo.svg"}
                       alt="" />

                    </div>
                    <div className="entity-swtich-btn">
                      <span className="entity-dropdown-btn">
                        {selected?.entity_name||"select entity"}
                      </span>
                      <i className="fa-regular fa-angle-down"></i>
                    </div>
                  </button>

                  <div className="dropdown-menu dropdown-menu-end">
                    <div className="select-entity-list">
                      <h4 style={{color:background}}>Select Entity</h4>
                      <ul>
                        {allEntity?.map((entity) => (
                          <li key={entity?.id}>
                            <button
                              type="button"
                              className={`dropdown-item ${
                                selected?.id === entity?.id ? "active" : ""
                              }`}
                              // onClick={() =>
                              // {  
                              //   setSelectedEntity(entity||"")
                              //   dispatch(selectEntity({entity_id:entity?.id}))
                              // }
                              // }

                              onClick={()=>{
                                handleSelectEntity(entity)
                                // dispatch(selectEntity({entity_id:entity?.id}))
                              }}
                            >
                              {entity?.entity_name}
                            </button>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>)}

                {/* NOTIFICATIONS */}
                <div className="notification">
                  <button
                    className="dropdown-toggle"
                    type="button"
                    data-bs-toggle="dropdown"
                    style={{color:background}}
                  >
                    <i className="hgi hgi-stroke hgi-notification-01" style={{color:background}}></i>
                    <span className="count" style={{background:background}}>2</span>
                  </button>

                  <div className="dropdown-menu dropdown-menu-end">
                    <div className="noti-dropdown">
                      <h2 style={{color:background}}>Notifications</h2>
                      <div className="noti-scroll">
                        <div className="noti-list">
                          {notification?.map((item) => (
                            <div className="noti-in" key={item.id}>
                              <h3>
                                {item.spoolNo} <b>{item.timeAgo}</b>
                              </h3>
                              <p>{item.project}</p>
                              <p>
                                <b>Admin reply:</b> {item.message}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* LOGOUT */}
                <button
                  onClick={() => setShowLogoutModal(true)}
                  className="logout-cta"
                  style={{background:background}}
                  type="button"
                  data-bs-toggle="modal"
                  data-bs-target="#logout-popup"
                >
                  Logout <i className="hgi hgi-stroke hgi-logout-circle-02"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <Logout show={showLogout} handleClose={() => setShowLogoutModal(false)} />
    </>
  );
};

export default Header;

// import React, { useState } from 'react'
// import Logout from './Logout'
// import { Link } from 'react-router-dom'
// import {notifications} from "../assets/data.json";

// // const entities = ["FabricationTech",
// //     "Global Industries",
// //      "TechPipe Solutions",
// //      "Industrial Works Co.",
// //       "Acme Manufacturing"];

// const ENTITY_THEME = {
//   Alice: "linear-gradient(135deg, #667eea, #764ba2)",
//   Bob: "linear-gradient(135deg, #f7971e, #ffd200)",
//   Carol: "linear-gradient(135deg, #56ab2f, #a8e063)",
//   Dave: "linear-gradient(135deg, #2193b0, #6dd5ed)",
//   Eve: "linear-gradient(135deg, #cc2b5e, #753a88)",
// };

// const entities = Object.keys(ENTITY_THEME);

// const Header = () => {

//  const [showLogout,setShowLogutModal]=useState(false)
//  const [selectedEntity, setSelectedEntity] = useState("FabricationTech");
//  const [notification,setNotification]=useState(notifications || [])

//   return (
//     <>
//         <header style={{
//                background: ENTITY_THEME[selectedEntity],
//         }}>
//             <div className="container">
//                 <div className="row">
//                     <div className="col-lg-6 col-md-3">
//                         <div className="header-in">
//                             <div className="logo">
//                                 <img src="/images/projects/logo-w.svg" alt=""/>
//                             </div>
//                             <div className="logo-data">
//                                 <img src="/images/projects/rpr-spool-tracker.svg" alt=""/>
//                                 <p>Logged in as <span>Arlene McCoy</span></p>
//                             </div>
//                         </div>
//                     </div>
//                     <div className="col-lg-6 col-md-9">
//                         <div className="header-right">
//                             <div className="entity-swtich entity-dropdown">
//                                 <button className="dropdown-toggle" type="button" data-bs-toggle="dropdown"
//                                     aria-expanded="false" aria-required="true" data-bs-auto-close="outside">
//                                     <div className="entity-logo">
//                                         <img src="/images/projects/entity-logo.svg" alt=""/>
//                                     </div>
//                                     <div className="entity-swtich-btn">
//                                         <span className="entity-dropdown-btn">FabricationTech</span>
//                                         <i className="fa-regular fa-angle-down"></i>
//                                     </div>
//                                 </button>
//                                 {/* <div className="dropdown-menu dropdown-menu-end">
//                                     <div className="select-entity-list">
//                                         <h4>Select Entity</h4>
//                                         <ul>
//                                             <li><button type="button"
//                                                     className="dropdown-item active">FabricationTech</button>
//                                             </li>
//                                             <li><button type="button" className="dropdown-item">Global Industries</button>
//                                             </li>
//                                             <li><button type="button" className="dropdown-item">TechPipe Solutions</button>
//                                             </li>
//                                             <li><button type="button" className="dropdown-item">Industrial Works
//                                                     Co.</button></li>
//                                             <li><button type="button" className="dropdown-item">Acme Manufacturing</button>
//                                             </li>
//                                         </ul>
//                                     </div>
//                                 </div> */}
//                                 <div className="dropdown-menu dropdown-menu-end">
//                                 <div className="select-entity-list">
//                                     <h4>Select Entity</h4>
//                                     <ul>
//                                     {entities.map((entity) => (
//                                         <li key={entity}>
//                                         <button
//                                             type="button"
//                                             className={`dropdown-item ${
//                                             selectedEntity === entity ? "active" : ""
//                                             }`}
//                                             onClick={() => setSelectedEntity(entity)}
//                                         >
//                                             {entity}
//                                         </button>
//                                         </li>
//                                     ))}
//                                     </ul>
//                                 </div>
//                                 </div>

//                             </div>
//                             <div className="notification">
//                                 <button className="dropdown-toggle" type="button" data-bs-toggle="dropdown"
//                                     aria-expanded="false" aria-required="true" data-bs-auto-close="outside">
//                                     {/* <!-- <img src="/images/projects/notification.svg" alt=""> --> */}
//                                     <i className="hgi hgi-stroke hgi-notification-01"></i>
//                                     <span className="count">2</span>
//                                 </button>
//                                 <div className="dropdown-menu dropdown-menu-end">
//                                     <div className="noti-dropdown">
//                                         <h2>Notifications</h2>
//                                         <div className="noti-scroll">
//                                             <div className="noti-list">
//                                              {  notification?.map(item=>(
//                                                 <div className="noti-in" key={item?.id}>
//                                                     <h3>{ item?.spoolNo ||"SP-2024-002"} <span></span> <b>{ item?.timeAgo ||"30m ago"}</b></h3>
//                                                     <p>{ item?.project ||"Pipeline Refinery A"}</p>
//                                                     <p><b>Admin reply:</b>{ item?.message ||" Issue reviewed. Please recheck the weld joint at section B-4."}</p>
//                                                 </div>
//                                              )) }
//                                             </div>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                             <button onClick={()=>setShowLogutModal(true)}
//                             //  data-bs-toggle="modal"
//                             //   data-bs-target="#logout-popup"
//                                className="logout-cta" type="button"
//                              >
//                                 Logout <i className="hgi hgi-stroke hgi-logout-circle-02"></i>
//                             </button>
//                         </div>
//                     </div>
//                 </div>
//             </div>
//         </header>

//         <Logout show={showLogout} handleClose={()=>setShowLogutModal(false)}/>

//     </>
//   )
// }

// export default Header
