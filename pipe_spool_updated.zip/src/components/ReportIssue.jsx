import React from 'react'

const ReportIssue = () => {
  return (
    <>
     <div className="modal fade other-popup" id="reported-issue-popup" tabindex="-1" aria-hidden="true">
        <div className="modal-dialog">
            <div className="modal-content">
                <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <i className="hgi hgi-stroke hgi-cancel-01"></i>
                </button>
                <div className="modal-body">
                    <div className="other-popup-in">
                        <div className="other-popup-icon">
                            <i className="hgi hgi-stroke hgi-flag-03"></i>
                        </div>
                        <div className="other-popup-data mb-0">
                            <h1>Reported Issue</h1>
                            <form action="">
                                <textarea
                                    readonly>Weld on joint J-14 required rework due to misalignment. Corrected on site but recommend checking fit-up tolerance for future spools.</textarea>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     </div>

    </>
  )
}

export default ReportIssue
